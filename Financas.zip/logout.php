<?php
    include "php/dados.php";
    session_start();
    logout();
?>